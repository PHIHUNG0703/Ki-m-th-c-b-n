/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import com.edusys.utils.XJDBC;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

/**
 *
 * @author ACER
 */
public class ChuyenDe {

    public static String getMaCD;
    private String maCD;
    private String tenCD;
    private double hocPhi;
    private int thoiLuong;
    private String hinh = "NoImage.png";
    private String moTa;

    public ChuyenDe() {
    }

    public ChuyenDe(String maCD, String tenCD, double hocPhi, int thoiLuong, String moTa) {
        this.maCD = maCD;
        this.tenCD = tenCD;
        this.hocPhi = hocPhi;
        this.thoiLuong = thoiLuong;
        this.moTa = moTa;
    }

    @Override
    public String toString(){
         
        return  maCD ;
    }
    
    public String getMaCD() {
        return maCD;
    }

    public void setMaCD(String maCD) {
        this.maCD = maCD;
    }

    public String getTenCD() {
        return tenCD;
    }

    public void setTenCD(String tenCD) {
        this.tenCD = tenCD;
    }

    public double getHocPhi() {
        return hocPhi;
    }

    public void setHocPhi(double hocPhi) {
        this.hocPhi = hocPhi;
    }

    public int getThoiLuong() {
        return thoiLuong;
    }

    public void setThoiLuong(int thoiLuong) {
        this.thoiLuong = thoiLuong;
    }

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }
    
    
}
