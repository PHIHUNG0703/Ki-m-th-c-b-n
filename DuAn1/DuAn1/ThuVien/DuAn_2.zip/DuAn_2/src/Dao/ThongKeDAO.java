/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.KhoaHoc;
import com.edusys.utils.XJDBC;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER
 */
public class ThongKeDAO {
    //rs = XJDBC.query(sql, args);

    public static ResultSet rs = null; // Trả về kết quả truy vấn

    public static String PieChart_sql = "SELECT YEAR(NGAYDK) NAM , COUNT(*) SOLUONG FROM NGUOIHOC GROUP BY YEAR(NGAYDK)";
    public static String BarChart_sql = "SELECT YEAR(NGAYKG) NAM , SUM( HOCPHI) HocPhiTB FROM KHOAHOC GROUP BY YEAR(NGAYKG)";
    public static String Cot_sql = "select top 5 k.MaCD, count(k.MaKH) as \"SLKH\"\n"
            + "from ChuyenDe c INNER JOIN KhoaHoc k\n"
            + "ON c.MaCD = k.MaCD\n"
            + "group by k.MaCD\n"
            +"order by \"SLKH\" desc;"
           ;

    private List<Object[]> getListOfArray(String sql, String[] cols, Object... args) {
        try {
            List<Object[]> list = new ArrayList<>();
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                Object[] vals = new Object[cols.length];
                for (int i = 0; i < cols.length; i++) {
                    vals[i] = rs.getObject(cols[i]);
                }
                list.add(vals);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Object[]> getBangDiem(Integer maKH) {
        String sql = "{CALL sp_BangDiem(?)}";
        String[] cols = {"MaNH", "HoTen", "Diem"};
        return this.getListOfArray(sql, cols, maKH);
    }

    public List<Object[]> getLuongNguoiHoc() {
        String sql = "{CALL sp_LuongNguoiHoc}";
        String[] cols = {"Nam", "SoLuong", "DauTien", "CuoiCung"};
        return this.getListOfArray(sql, cols);
    }

    public List<Object[]> getDiemChuyenDe() {
        String sql = "{CALL sp_DiemChuyenDe}";
        String[] cols = {"ChuyenDe", "SoHV", "ThapNhat", "CaoNhat", "TrungBinh"};
        return this.getListOfArray(sql, cols);
    }

    public List<Object[]> getDoanhThu(Integer nam) {
        String sql = "{CALL sp_DoanhThu(?)}";
        String[] cols = {"ChuyenDe", "SoKH", "SoHV", "DoanhThu", "ThapNhat", "CaoNhat", "TrungBinh"};
        return this.getListOfArray(sql, cols, nam);
    }
    public List<Object[]> getGoiY() {
        String sql ="{CALL sp_GoiY}";
        String[] colos ={"MaCD","SLKH","SLHV"};
        return  this.getListOfArray(sql, colos);
    }

    public List<Object[]> getPie_Chart() {

        String[] cols = {"Nam", "SoLuong"};
        return this.getListOfArray(PieChart_sql, cols);
    }

    public List<Object[]> getBar_chart() {
        String[] cols = {"Nam", "HocPhiTB"};
        return this.getListOfArray(BarChart_sql, cols);
    }

    public List<Object[]> getBieuDo_chart() {
        String[] cols = {"MaCD","SLKH"};
        return  this.getListOfArray(Cot_sql, cols);
    }
}
