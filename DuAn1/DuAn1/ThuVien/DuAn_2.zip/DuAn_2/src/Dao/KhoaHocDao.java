/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import static Dao.NhanVienDao.SELECT_ALL_SQL;
import static Dao.NhanVienDao.SELECT_BY_ID_SQL;
import com.edusys.utils.XJDBC;
import java.sql.ResultSet;
import Model.KhoaHoc;
import Model.NhanVien;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER
 */
public class KhoaHocDao extends EduSysDAO<KhoaHoc, Integer> {

    public static ResultSet rs = null; // Trả về kết quả truy vấn
    public static String INSERT_SQL = "INSERT INTO KhoaHoc (MaCD,HocPhi,ThoiLuong,NgayKG,GhiChu,MaNV,NgayTao) VALUES (?,?,?,?,?,?,?)";           
    public static String UPDATE_SQL = "UPDATE KhoaHoc SET MaCD=?,HocPhi=?,ThoiLuong=?,NgayKG=?,GhiChu=?,MaNV=? WHERE MaKH=?";         
    public static String DELETE_SQL = "DELETE FROM KhoaHoc WHERE MaKH=?";
    public static String SELECT_ALL_SQL = "SELECT * FROM KHOAHOC";
    public static String SELECT_BY_ID_SQL = "SELECT * FROM KhoaHoc WHERE MaKH=?";
    public static String SELECT_BY_CD_SQL = "SELECT * FROM KhoaHoc WHERE MaCD=?";
    public static String SELECT_YEARS_SQL = "SELECT DISTINCT year(NgayKG) Year FROM KhoaHoc ORDER BY Year DESC";


    @Override
    public void insert(KhoaHoc entity) {
        XJDBC.update(INSERT_SQL,
                entity.getMaCD(),
                entity.getHocPhi(),
                entity.getThoiLuong(),
                entity.getNgayKG(),
                entity.getGhiChu(),
                entity.getMaNV(),
                    entity.getNgayTao());
                
    }

    @Override
    public void update(KhoaHoc entity) {
        XJDBC.update(UPDATE_SQL,
                entity.getMaCD(),
                entity.getHocPhi(),
                entity.getThoiLuong(),
                entity.getNgayKG(),
                entity.getGhiChu(),
                entity.getMaNV(),
                entity.getMaKH());
    }

    @Override
    public void delete(Integer id) {
        XJDBC.update(DELETE_SQL, id);
    }

    @Override
    public List<KhoaHoc> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public KhoaHoc selectById(Integer id) {
        List<KhoaHoc> list = selectBySql(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;

        }
        return list.get(0);

    }

    @Override
    protected List<KhoaHoc> selectBySql(String sql, Object... args) {
        List<KhoaHoc> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                KhoaHoc entity = new KhoaHoc();
                entity.setMaKH(rs.getInt("MaKH"));           
                entity.setHocPhi(rs.getDouble("HocPhi"));
                entity.setThoiLuong(rs.getInt("ThoiLuong"));
                entity.setNgayKG(rs.getDate("NgayKG"));
                entity.setGhiChu(rs.getString("GhiChu"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setNgayTao(rs.getDate("NgayTao"));
                entity.setMaCD(rs.getString("MaCD"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);

        }
        return list;
    }

    public List<KhoaHoc> selectKhoaHocByChuyenDe(String maCD) {
           return selectBySql(SELECT_BY_CD_SQL,maCD);
    }

    public List<Integer> SelectYears(){
         String sql = "SELECT DISTINCT year(NgayKG) Year FROM KHOAHOC ORDER BY Year DESC";
         List<Integer> list = new ArrayList<>();
         try {
             ResultSet rs = XJDBC.query(sql);
             while (rs.next()){
                 list.add(rs.getInt(1));
             }
             rs.getStatement().getConnection().close();
             return list;
         } catch (Exception e) {
             throw  new RuntimeException(e);
         }
     }
}
