/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import static Dao.NhanVienDao.SELECT_ALL_SQL;
import static Dao.NhanVienDao.SELECT_BY_ID_SQL;
import com.edusys.utils.XJDBC;
import java.sql.ResultSet;
import Model.NguoiHoc;
import Model.NhanVien;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER
 */
public class NguoiHocDao extends EduSysDAO<NguoiHoc, String> {

    public static ResultSet rs = null; // Trả về kết quả truy vấn
    public static String INSERT_SQL = "INSERT INTO NGUOIHOC(MANH, HOTEN, GIOITINH, NGAYSINH, DIEMTHOAI, EMAIL, GHICHU, MANV, NGAYDK) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    public static String UPDATE_SQL = "UPDATE NGUOIHOC SET HOTEN = ?, GIOITINH = ?, NGAYSINH = ?, DIEMTHOAI = ?, EMAIL = ?, GHICHU = ?, MANV = ?, NGAYDK = ? WHERE MANH = ?";
    public static String DELETE_SQL = "DELETE FROM NGUOIHOC WHERE MANH = ?";
    public static String SELECT_ALL_SQL = "SELECT * FROM NGUOIHOC";
    public static String SELECT_BY_ID_SQL = "SELECT * FROM NGUOIHOC WHERE MANH = ?";
    public static String SELECT_NOT_IN_COURSE = "SELECT * FROM NguoiHoc WHERE HoTen LIKE ? AND MaNH NOT IN "
            + "(SELECT MaNH FROM HocVien WHERE MaKH = ?)";
     public static String SELECT_BY_KEYWORD_SQL = "SELECT * FROM NguoiHoc WHERE (HoTen LIKE ? "
            + "OR MaNH LIKE ? OR DienThoai LIKE ?) AND MaNH NOT IN (SELECT MaNH FROM HocVien WHERE MaKH=?)";


    @Override
    public void insert(NguoiHoc entity) {
        
        XJDBC.update(INSERT_SQL, 
                entity.getMaNH(), 
                entity.getHoTen(), 
                entity.isGioiTinh(), 
                entity.getNgaySinh(),
                entity.getDienThoai(),
                entity.getEmail(), 
                entity.getGhiChu(), 
                entity.getMaNV(), 
                entity.getNgayDK());
    }

    @Override
    public void update(NguoiHoc entity) {
        XJDBC.update(UPDATE_SQL, 
                entity.getHoTen(),
                entity.isGioiTinh(), 
                entity.getNgaySinh(), 
                entity.getDienThoai(),
                entity.getEmail(), 
                entity.getGhiChu(), 
                entity.getMaNV(), 
                entity.getNgayDK(), 
                entity.getMaNH());
    }

    @Override
    public void delete(String id) {
        XJDBC.update(DELETE_SQL, id);
    }

    @Override
    public List<NguoiHoc> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public NguoiHoc selectById(String id) {
        List<NguoiHoc> list = selectBySql(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NguoiHoc> selectBySql(String sql, Object... args) {
        List<NguoiHoc> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                NguoiHoc entity = new NguoiHoc();
                entity.setMaNH(rs.getString("MANH"));
                entity.setHoTen(rs.getString("HOTEN"));
                entity.setGioiTinh(rs.getBoolean("GIOITINH"));
                entity.setNgaySinh(rs.getDate("NGAYSINH"));
                entity.setDienThoai(rs.getString("DIEMTHOAI"));
                entity.setEmail(rs.getString("EMAIL"));
                entity.setGhiChu(rs.getString("GHICHU"));
                entity.setMaNV(rs.getString("MANV"));
                entity.setNgayDK(rs.getDate("NGAYDK"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

   public List<NguoiHoc> selectNotInCourse(int maNH, String keyword) {
        return selectBySql(SELECT_NOT_IN_COURSE, "%"+keyword+"%",maNH);
    }

    public List<NguoiHoc> selectByKeyword(int makh, String key) {
        return this.selectBySql(SELECT_BY_KEYWORD_SQL, "%" + key + "%", "%" + key + "%", "%" + key + "%", makh);
    }
}
