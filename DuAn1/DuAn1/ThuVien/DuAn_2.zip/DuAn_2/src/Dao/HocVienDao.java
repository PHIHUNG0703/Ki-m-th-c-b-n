/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import com.edusys.utils.XJDBC;
import java.sql.ResultSet;
import Model.HocVien;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER
 */
public class HocVienDao extends EduSysDAO<HocVien, String> {

    public static String INSERT_SQL = "INSERT INTO HOCVIEN( MAKH, MANH, DIEM) VALUES (?,?,?)";
    public static String UPDATE_SQL = "UPDATE HOCVIEN SET  MAKH = ?, MANH = ?,DIEM = ? WHERE MAHV = ?";
    public static String DELETE_SQL = "DELETE FROM HOCVIEN WHERE MAHV = ?";
    public static String SELECTALL = "SELECT * FROM HOCVIEN";
    public static String SELECTBYID = "SELECT * FROM HOCVIEN WHERE MAHV = ?";
    public static String SELECT_BY_KHOA_HOC = "SELECT * FROM HocVien WHERE MaKH= ?";

    @Override
    public void insert(HocVien entity) {
        XJDBC.update(INSERT_SQL,
                entity.getMaKH(),
                entity.getMaNH(),
                entity.getDiem()
        );
    }

    @Override
    public void update(HocVien entity) {
        XJDBC.update(UPDATE_SQL,
                entity.getMaKH(),
                entity.getMaNH(),
                entity.getDiem(),
                entity.getMaHV()
        );

    }

    @Override
    public void delete(String id) {
        XJDBC.update(DELETE_SQL, id);
    }

    @Override
    public List<HocVien> selectAll() {
        return selectBySql(SELECTALL);
    }

    @Override
    public HocVien selectById(String id) {
        List<HocVien> list = selectBySql(SELECTBYID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);

    }

    @Override
    protected List<HocVien> selectBySql(String sql, Object... args) {
        List<HocVien> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                HocVien entity = new HocVien();
                entity.setMaHV(rs.getInt("MaHV"));
                entity.setMaKH(rs.getInt("MaKH"));
                entity.setMaNH(rs.getString("MaNH"));
                entity.setDiem(rs.getDouble("Diem"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<HocVien> selectByKhoaHoc(int maKH) {
        return selectBySql(SELECT_BY_KHOA_HOC, maKH);
    }

    public HocVien selectById(int maHV) {
        List<HocVien> list = selectBySql(SELECTBYID, maHV);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public void delete(int maHV) {
         XJDBC.update(DELETE_SQL, maHV);
    }

}
