/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Form;

import Model.ChuyenDe;
import Dao.ChuyenDeDao;
import Model.NhanVien;
import com.edusys.utils.XAuth;
import com.edusys.utils.XDialog;
import com.edusys.utils.XImage;
import com.edusys.utils.XMsgBox;
import com.edusys.utils.XValidate;
import static com.edusys.utils.XValidate.cddao;
import java.io.File;
import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.TabSet;

/**
 *
 * @author ACER
 */
public class QLChuyenDe extends javax.swing.JDialog {

    JFileChooser fileChooser = new JFileChooser();
    ChuyenDeDao dao = new ChuyenDeDao();
    int row = 0;

    /**
     * Creates new form QLChuyenDe
     */
    public QLChuyenDe(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        init();
    }

    public void init() {
        setIconImage(XImage.getAppIcon());
        setLocationRelativeTo(null);
        setTitle("Quan lí chuyên đề");
        fillTable();
        row = -1;
        updateStatus();

    }

    public void ChonAnh() {
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            XImage.saveIconCD(file);
            ImageIcon icon = XImage.readIconCD(file.getName());
            tblHinh.setIcon(icon);
            tblHinh.setToolTipText(file.getName());
        }
    }

    public void setForm(ChuyenDe model) {
        txtMaCD.setText(model.getMaCD());
        txtTenCD.setText(model.getTenCD());
        txtGio.setText(String.valueOf(model.getThoiLuong()));
        txtHocPhi.setText(String.valueOf(formatNUmber(model.getHocPhi())));
        txtGhiChu.setText(model.getMoTa());
        tblHinh.setIcon(XImage.readIconCD("NoImage.png"));
        if (model.getHinh() != null) {
            tblHinh.setToolTipText(model.getHinh());
            tblHinh.setIcon(XImage.readIconCD(model.getHinh()));
        }
    }

    public ChuyenDe getForm() {
        ChuyenDe cd = new ChuyenDe();
        cd.setMaCD(txtMaCD.getText());
        cd.setTenCD(txtTenCD.getText());
        cd.setThoiLuong(Integer.valueOf(txtGio.getText()));
        cd.setHocPhi(Double.valueOf(txtHocPhi.getText()));
        cd.setMoTa(txtGhiChu.getText());

        String hinh = tblHinh.getToolTipText();
        if (hinh == null || hinh.isEmpty()) {
            hinh = "NoImage.png";
        }
        cd.setHinh(hinh);

        return cd;
    }

    public void edit() {
        String macd = (String) tblCD.getValueAt(this.row, 0);
        ChuyenDe cd = dao.selectById(macd);
        if (cd != null) {
            setForm(cd);
            updateStatus();
            tabs.setSelectedIndex(0);
        }
//        this.updateStatus();        
    }

    public void updateStatus() {
        boolean edit = this.row >= 0;
        boolean first = this.row == 0;
        boolean last = this.row == tblCD.getRowCount() - 1;

        txtMaCD.setEditable(!edit);
        btnThem.setEnabled(!edit);
        btnSua.setEnabled(edit);
        btnXoa.setEnabled(edit);
        btnTien.setEnabled(edit);
        btnLui.setEnabled(edit);
        btnDau.setEnabled(edit);
        btnCuoi.setEnabled(edit);
    }

    public void ClearForm() {
        this.setForm(new ChuyenDe());
        row = -1;
        updateStatus();
    }

    public void fillTable() {
        DefaultTableModel model = (DefaultTableModel) tblCD.getModel();
        model.setRowCount(0);
        try {
            List<ChuyenDe> list = dao.selectAll();
            for (ChuyenDe cd : list) {
                Object[] row = {
                    cd.getMaCD(),
                    cd.getTenCD(),
                    formatNUmber(cd.getHocPhi()),
                    cd.getThoiLuong(),
                    cd.getHinh(),
                    cd.getMoTa()
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            XMsgBox.alert(this, "Loi truy cap du lieu");
        }
    }

    public boolean checkMa() {
        boolean valid = true;

        String maCD = txtMaCD.getText();
        if (maCD.isEmpty()) {
            XMsgBox.alert(this, "Chưa nhập mã chuyên đề!");
            return false;
        }

        String regex = "[a-zA-Z0-9]{5}$";
        if (!maCD.matches(regex)) {
            XDialog.alert(this, "Mã chuyên đề phải có đúng 5 kí tự\n(chữ hoa, thường không dấu hoặc số).");
            return false;
        }

        if (cddao.selectById(maCD) != null) {
            XDialog.alert(this, "Mã chuyên đề '" + maCD + "' đã tồn tại.");
            return false;
        }

        return valid;
    }

    public boolean checkTen() {
        boolean valid = true;

        String tenCD = txtTenCD.getText();
        if (tenCD.isEmpty()) {
            XMsgBox.alert(this, "Chưa nhập tên chuyên đề!");
            return false;
        }

        String regex = ".{3,50}";
        if (!tenCD.matches(regex)) {
            XDialog.alert(this, "Tên phải có từ 3-50 kí tự.");
            return false;
        }

        return valid;
    }

    public boolean checkGio() {
        boolean valid = true;

        String gio = txtGio.getText();
        if (gio.isEmpty()) {
            XMsgBox.alert(this, "Chưa nhập thời lượng!");
            return false;
        }

        try {
            int hour = Integer.parseInt(gio);
            if (hour < 0) {
                XDialog.alert(this, "Thời lượng phải lớn hơn 0.");
                return false;
            }
        } catch (NumberFormatException e) {
            XDialog.alert(this, "Thời lượng phải là số không được nhập chữ .");
            return false;
        }

        return valid;
    }

    public static boolean checkHocPhi(JTextField txt) {
        String text = txt.getText().trim(); // Lấy giá trị và loại bỏ khoảng trắng
        if (text.isEmpty()) {
            XDialog.alert(txt, "Vui lòng nhập học phí.");
            return false;
        }

        try {
            float hp = Float.parseFloat(text);
            if (hp >= 0) {
                return true;
            } else {
                XDialog.alert(txt, "Học phí phải là lớn hơn hoặc bằng 0.");
                return false;
            }
        } catch (NumberFormatException e) {
            XDialog.alert(txt, "Học phí phải là số.");
            return false;
        }
    }

    public void them() {
        ChuyenDe CD = getForm();
        if (CD.getHinh() == null || CD.getHinh().isEmpty()) {
            // Nếu hình ảnh không được chọn, gán một hình ảnh mặc định hoặc trống cho cột HINH.
            CD.setHinh("NoImage.png");

        }
        try {
            dao.insert(CD);
            this.fillTable();
            this.ClearForm();
            XMsgBox.alert(this, "Thêm mới thành công");
        } catch (Exception e) {
            XMsgBox.alert(this, "Thêm mới thất bại" + e.getMessage());
        }
    }

    public void sua() {
        ChuyenDe model = getForm();

        try {
            dao.update(model);
            this.fillTable();
            XMsgBox.alert(this, "Cap nhat thanh cong");
        } catch (Exception e) {
            XMsgBox.alert(this, "Cap nhat that bai");
        }

    }

    public void xoa() {
        if (!XAuth.isManager()) {
            XMsgBox.alert(this, "Bạn không có quyền xóa");

        } else {
            if (XMsgBox.confirm(this, "Bạn có muốn xóa chuyên đề này")) {
                String MaCD = txtMaCD.getText();
                try {
                    dao.delete(MaCD);
                    this.fillTable();
                    this.ClearForm();
                    XMsgBox.alert(this, "Đã xóa thành công");
                } catch (Exception e) {
                    XMsgBox.alert(this, "Xóa thất bại");
                }
            }
        }
    }

    public void moi() {
        ChuyenDe CD = new ChuyenDe();
        this.setForm(CD);
        this.row = -1;
        this.updateStatus();
    }

    private void dau() {
        if (tblCD.getRowCount() > 0) {
            row = 0;
            edit();
        }
    }

    private void cuoi() {
        if (tblCD.getRowCount() > 0) {
            row = tblCD.getRowCount() - 1;
            edit();
        }
    }

    private void len() {
        if (tblCD.getRowCount() > 0 && row > 0) {
            row--;
            edit();
        }
    }

    private void xuong() {
        if (tblCD.getRowCount() > 0 && row < tblCD.getRowCount() - 1) {
            row++;
            edit();
        }
    }

    public String formatNUmber(double number) {
        DecimalFormat diDecimalFormat = new DecimalFormat("#");
        return diDecimalFormat.format(number);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabs = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        tblHinh = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMaCD = new javax.swing.JTextField();
        txtTenCD = new javax.swing.JTextField();
        txtGio = new javax.swing.JTextField();
        txtHocPhi = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtGhiChu = new javax.swing.JTextArea();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        btnDau = new javax.swing.JButton();
        btnLui = new javax.swing.JButton();
        btnTien = new javax.swing.JButton();
        btnCuoi = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCD = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tabs.setBackground(new java.awt.Color(201, 229, 229));

        jPanel2.setBackground(new java.awt.Color(238, 229, 229));

        tblHinh.setBackground(new java.awt.Color(204, 204, 204));
        tblHinh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblHinh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHinhMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblHinhMousePressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Hình ảnh");

        txtMaCD.setBackground(new java.awt.Color(209, 232, 232));

        txtTenCD.setBackground(new java.awt.Color(191, 228, 228));

        txtGio.setBackground(new java.awt.Color(184, 234, 234));

        txtHocPhi.setBackground(new java.awt.Color(188, 227, 227));
        txtHocPhi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHocPhiActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Mã chuyên đề");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Tên chuyên đề");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Thời lượng(giờ)");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Học phí");

        txtGhiChu.setBackground(new java.awt.Color(180, 221, 221));
        txtGhiChu.setColumns(20);
        txtGhiChu.setRows(5);
        txtGhiChu.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ghi chú", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jScrollPane1.setViewportView(txtGhiChu);

        btnThem.setBackground(new java.awt.Color(204, 255, 255));
        btnThem.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnThem.setForeground(new java.awt.Color(51, 102, 0));
        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/insert.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setBackground(new java.awt.Color(204, 255, 255));
        btnSua.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSua.setForeground(new java.awt.Color(51, 102, 0));
        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/update.png"))); // NOI18N
        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setBackground(new java.awt.Color(204, 255, 255));
        btnXoa.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnXoa.setForeground(new java.awt.Color(51, 102, 0));
        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/trash.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnMoi.setBackground(new java.awt.Color(204, 255, 255));
        btnMoi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMoi.setForeground(new java.awt.Color(51, 102, 0));
        btnMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/reset.png"))); // NOI18N
        btnMoi.setText("Mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        btnDau.setBackground(new java.awt.Color(0, 255, 153));
        btnDau.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDau.setText("<<");
        btnDau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDauActionPerformed(evt);
            }
        });

        btnLui.setBackground(new java.awt.Color(0, 255, 153));
        btnLui.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLui.setText("I<");
        btnLui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuiActionPerformed(evt);
            }
        });

        btnTien.setBackground(new java.awt.Color(0, 255, 153));
        btnTien.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTien.setText(">I");
        btnTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTienActionPerformed(evt);
            }
        });

        btnCuoi.setBackground(new java.awt.Color(0, 255, 153));
        btnCuoi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCuoi.setText(">>");
        btnCuoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuoiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addGap(18, 18, 18)
                        .addComponent(btnSua)
                        .addGap(26, 26, 26)
                        .addComponent(btnXoa)
                        .addGap(18, 18, 18)
                        .addComponent(btnMoi))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(btnDau)
                            .addGap(18, 18, 18)
                            .addComponent(btnLui)
                            .addGap(33, 33, 33)
                            .addComponent(btnTien)
                            .addGap(18, 18, 18)
                            .addComponent(btnCuoi))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tblHinh, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(60, 60, 60)
                                        .addComponent(jLabel3)))
                                .addGap(30, 30, 30)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel7)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtGio, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtTenCD, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtMaCD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addComponent(txtHocPhi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tblHinh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(48, 48, 48))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtMaCD, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtTenCD, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txtGio, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel7)
                        .addGap(16, 16, 16)
                        .addComponent(txtHocPhi, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnMoi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCuoi)
                    .addComponent(btnTien)
                    .addComponent(btnLui)
                    .addComponent(btnDau))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabs.addTab("Cập nhật", jPanel2);

        tblCD.setBackground(new java.awt.Color(205, 234, 234));
        tblCD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã CD", "Tên CD", "Học phí", "Thời lượng", "Hình", "Mô tả"
            }
        ));
        tblCD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblCDMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblCD);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 690, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tabs.addTab("Danh sách", jPanel1);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Quản lí chuyên đề");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 690, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 7, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(254, 254, 254))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTienActionPerformed
        // TODO add your handling code here:
        xuong();
    }//GEN-LAST:event_btnTienActionPerformed

    private void tblHinhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHinhMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblHinhMouseClicked

    private void tblHinhMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHinhMousePressed
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            ChonAnh();
        }
    }//GEN-LAST:event_tblHinhMousePressed

    private void tblCDMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCDMousePressed
        // TODO add your handling code here:
        if (evt.getClickCount() == 1) {
            this.row = tblCD.rowAtPoint(evt.getPoint());
            edit();
        }
    }//GEN-LAST:event_tblCDMousePressed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        if (checkMa() && checkTen() && checkGio() && checkHocPhi(txtHocPhi)) {
            them();
        }


    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
if (checkHocPhi(txtHocPhi)) {
            sua();
        }

    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        xoa();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        // TODO add your handling code here:
        moi();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnDauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDauActionPerformed
        // TODO add your handling code here:
        dau();
    }//GEN-LAST:event_btnDauActionPerformed

    private void btnCuoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuoiActionPerformed
        // TODO add your handling code here:
        cuoi();
    }//GEN-LAST:event_btnCuoiActionPerformed

    private void btnLuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuiActionPerformed
        // TODO add your handling code here:
        len();
    }//GEN-LAST:event_btnLuiActionPerformed

    private void txtHocPhiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHocPhiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHocPhiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLChuyenDe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLChuyenDe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLChuyenDe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLChuyenDe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLChuyenDe dialog = new QLChuyenDe(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCuoi;
    private javax.swing.JButton btnDau;
    private javax.swing.JButton btnLui;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTien;
    private javax.swing.JButton btnXoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTable tblCD;
    private javax.swing.JLabel tblHinh;
    private javax.swing.JTextArea txtGhiChu;
    private javax.swing.JTextField txtGio;
    private javax.swing.JTextField txtHocPhi;
    private javax.swing.JTextField txtMaCD;
    private javax.swing.JTextField txtTenCD;
    // End of variables declaration//GEN-END:variables

}
