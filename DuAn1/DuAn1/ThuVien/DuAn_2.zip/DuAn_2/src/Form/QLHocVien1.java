/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Form;

import Dao.ChuyenDeDao;
import Dao.HocVienDao;
import Dao.KhoaHocDao;
import Dao.NguoiHocDao;
import Model.ChuyenDe;
import Model.NguoiHoc;
import Model.KhoaHoc;
import Model.HocVien;
import com.edusys.utils.XAuth;
import com.edusys.utils.XDialog;
import com.edusys.utils.XImage;
import com.edusys.utils.XMsgBox;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ACER
 */
public class QLHocVien1 extends javax.swing.JDialog {

    ChuyenDeDao CDdao = new ChuyenDeDao();
    HocVienDao HvDao = new HocVienDao();
    NguoiHocDao NHdDao = new NguoiHocDao();
    KhoaHocDao KHDao = new KhoaHocDao();
    private int row;

    /**
     * Creates new form QLHocVien
     */
    public QLHocVien1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        init();
    }

    public void init() {
        setLocationRelativeTo(null);
        setTitle("QUẢN LÝ HỌC VIÊN");
        fillComboBoxChuyenDe();

    }

    public void fillComboBoxChuyenDe() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboCD.getModel();
        model.removeAllElements();
        try {
            List<ChuyenDe> list = CDdao.selectAll();
            for (ChuyenDe cd : list) {
                model.addElement(cd);
                
            }
          // fillComboBoxKhoaHoc();
           fillTableKhoaHoc();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Loi CD");
        }

    }

    public void fillComboBoxKhoaHoc() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboKH.getModel();
        model.removeAllElements();
        try {
            ChuyenDe chuyende = (ChuyenDe) cboCD.getSelectedItem();
            if (chuyende != null) {
                List<KhoaHoc> list = KHDao.selectKhoaHocByChuyenDe(chuyende.getMaCD());
                for (KhoaHoc khoaHoc : list) {
                    model.addElement(khoaHoc);
                }
            }
            fillTableNguoiHoc();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void fillTableKhoaHoc() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboKH.getModel();
        model.removeAllElements();
        try {
            ChuyenDe chuyende = (ChuyenDe) cboCD.getSelectedItem();
            if (chuyende != null) {
                List<KhoaHoc> list = KHDao.selectKhoaHocByChuyenDe(chuyende.getMaCD());
                for (KhoaHoc khoaHoc : list) {
                    model.addElement(khoaHoc);
                }
            }
            fillTableNguoiHoc();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }
    public void fillTableNguoiHoc() {
        DefaultTableModel model = (DefaultTableModel) tblNH.getModel();
        model.setRowCount(0); // Xóa dữ liệu cũ trong bảng
        try {
            KhoaHoc selectedKhoaHoc = (KhoaHoc) cboKH.getSelectedItem();
            if (selectedKhoaHoc != null) {
                int maKH = selectedKhoaHoc.getMaKH();
                String keyword = txtTimKiem.getText();
                List<NguoiHoc> list = NHdDao.selectNotInCourse(maKH, keyword);
                for (NguoiHoc nguoiHoc : list) {
                    Object[] row = {
                        nguoiHoc.getMaNH(),
                        nguoiHoc.getHoTen(),
                        nguoiHoc.getNgaySinh(),
                        nguoiHoc.isGioiTinh() ? "Nam" : "Nữ",
                        nguoiHoc.getDienThoai(),
                        nguoiHoc.getEmail()
                    };
                    model.addRow(row);
                }
            }
        } catch (Exception e) {
            XMsgBox.alert(this, "Lỗi Nguoi Hoc");
            e.printStackTrace();
        }
    }

    public void fillTableHocVien() {
        DefaultTableModel model = (DefaultTableModel) tblHocVien.getModel();
        model.setRowCount(0);
        try {
            KhoaHoc kh = (KhoaHoc) cboKH.getSelectedItem();
            if (kh != null) {
                System.out.println("fillcomboBoxHocVien MaKH: " + kh.getMaKH());
                List<HocVien> list = HvDao.selectByKhoaHoc(kh.getMaKH());
                System.out.println("list: " + list.size());
                for (int i = 0; i < list.size(); i++) {
                    HocVien hv = list.get(i);
                    String hoten = NHdDao.selectById(hv.getMaNH()).getHoTen();
                    Object[] row = {
                        i + 1, hv.getMaHV(), hv.getMaNH(), hoten, hv.getDiem()
                    };
                    model.addRow(row);
                }
            }
            fillTableNguoiHoc();
        } catch (Exception e) {
            XMsgBox.alert(this, "Loi Hoc vien");
        }
    }
    
   

public boolean kiemTraGiaTriDiem(String value) {
    String regex = "^[0-9]+(\\.[0-9]+)?$";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(value);
    return matcher.matches();
}

public boolean kiemTraDiem(double diem) {
    return diem >= 0 && diem <= 10;
}
   

    public void themHV() {
        KhoaHoc kh = (KhoaHoc) cboKH.getSelectedItem();
        for (int row : tblNH.getSelectedRows()) {
            HocVien hv = new HocVien();
            hv.setMaKH(kh.getMaKH());
            hv.setDiem(0);
            hv.setMaNH((String) tblNH.getValueAt(row, 0));
            System.out.println("=> " + hv.getMaKH() + "-" + hv.getMaNH() + "-" + hv.getDiem());
            HvDao.insert(hv);
        }
        fillTableHocVien();
        tabs.setSelectedIndex(0);
    }
    
    public void capnhat() {
    for (int i = 0; i < tblHocVien.getRowCount(); i++) {
        int maHV = (Integer) tblHocVien.getValueAt(i, 1);
        HocVien hv = HvDao.selectById(maHV);
        Object cellValu = tblHocVien.getValueAt(i, 4).toString();

        if (kiemTraGiaTriDiem((String) cellValu)) {
            double diem = Double.parseDouble((String) cellValu);
            if (kiemTraDiem(diem)) {
                hv.setDiem(diem);
                HvDao.update(hv);
            } else {
                XMsgBox.alert(this, "Điểm không được lớn hơn 10 và nhỏ hơn 0");
                return; // Dừng việc cập nhật nếu có lỗi
            }
        } else {
            XMsgBox.alert(this, "Không được nhập chữ và số âm vui lòng nhập đúng");
            return; // Dừng việc cập nhật nếu có lỗi
        }
    }
    XMsgBox.alert(this, "Cập nhật thành công");
}

//    public void capnhat() {
//        for (int i = 0; i < tblHocVien.getRowCount(); i++) {
//            int maHV = (Integer) tblHocVien.getValueAt(i, 1);
//            HocVien hv = HvDao.selectById(maHV);
//            // hv.setDiem((Double) tblHocVien.getValueAt(i, 4));
//            hv.setDiem(Double.parseDouble(tblHocVien.getValueAt(i, 4).toString()));
//            HvDao.update(hv);
//        }
//        XMsgBox.alert(this, "Cap nhat thanh cong");
//    }

    private void xoa() {
        if (!XAuth.isManager()) {
            XDialog.alert(this, "Bạn không đủ quyền để xóa!");
        } else {
            int[] rows = tblHocVien.getSelectedRows();
            if (rows.length > 0 && XDialog.confirm(this, "Bạn có muốn xóa học viên đã chọn không?")) {
                for (int row : rows) {
                    int mahv = (Integer) tblHocVien.getValueAt(row, 1);
                    HvDao.delete(mahv);
                }
                fillTableHocVien();
            }
        }
    }

   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCapNhat = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cboCD = new javax.swing.JComboBox<>();
        tabs = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHocVien = new javax.swing.JTable();
        btnXoa = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtTimKiem = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblNH = new javax.swing.JTable();
        btnThem = new javax.swing.JButton();
        cboKH = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        btnCapNhat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/update.png"))); // NOI18N
        btnCapNhat.setText("Cập nhật điểm");
        btnCapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Quản lí học viên");

        cboCD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lập trình java cơ bản", "Item 2", "Item 3", "Item 4" }));
        cboCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCDActionPerformed(evt);
            }
        });

        tblHocVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "TT", "Mã HV", "Mã NH", "Họ và tên", "Điểm"
            }
        ));
        jScrollPane1.setViewportView(tblHocVien);

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/trash.png"))); // NOI18N
        btnXoa.setText("Xóa khỏi bảng");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnXoa)
                .addGap(244, 244, 244))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnXoa)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        tabs.addTab("Học viên", jPanel1);

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        tblNH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã NH", "Họ tên", "Giới tính ", "Ngày sinh", "SDT", "Email"
            }
        ));
        jScrollPane2.setViewportView(tblNH);

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/insert.png"))); // NOI18N
        btnThem.setText("Thêm khóa học");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 406, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(btnThem)
                                .addGap(158, 158, 158))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(105, 105, 105))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnThem)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        tabs.addTab("Người học", jPanel2);

        cboKH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "java01", "Item 2", "Item 3", "Item 4" }));
        cboKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboKHActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/open-book.png"))); // NOI18N
        jLabel2.setText("Chuyên đề");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edusys/icons/book.png"))); // NOI18N
        jLabel3.setText("Khóa học");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(cboCD, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(cboKH, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(tabs))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(290, 290, 290)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboCD, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(cboKH))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboKHActionPerformed
        // TODO add your handling code here:
        fillTableHocVien();
    }//GEN-LAST:event_cboKHActionPerformed

    private void cboCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCDActionPerformed
        // TODO add your handling code here:
     //   fillComboBoxKhoaHoc();
     fillTableKhoaHoc();
    }//GEN-LAST:event_cboCDActionPerformed

    private void btnCapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatActionPerformed
        // TODO add your handling code here:
        
            capnhat();
       
    }//GEN-LAST:event_btnCapNhatActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        themHV();
    }//GEN-LAST:event_btnThemActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        // TODO add your handling code here:
     
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
        // fillcomboBoxNguoiHoc();
        // timkiem();
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        xoa();
    }//GEN-LAST:event_btnXoaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLHocVien1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLHocVien1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLHocVien1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLHocVien1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLHocVien1 dialog = new QLHocVien1(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCapNhat;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cboCD;
    private javax.swing.JComboBox<String> cboKH;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTable tblHocVien;
    private javax.swing.JTable tblNH;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
