package com.edusys.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author ACER
 */
public class XJDBC {

    public static Connection connection = null; // Kết nối với sql
    public static PreparedStatement ps = null; // Câu lệnh SQL được biên dịch trước
    public static ResultSet rs = null; // Trả về kết quả truy vấn

    private static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static String connectionUrl = "jdbc:sqlserver://localhost:1433;"
            + "databaseName=QLKH;"
            + "user=sa;password=123;"
            + "encrypt=true;trustServerCertificate=true;";

    /*
     */
    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    /*

     */

    public static PreparedStatement getStmt(String sql, Object... args) {
    try {
        connection = DriverManager.getConnection(connectionUrl);

        if (sql.trim().startsWith("{")) {
            ps = connection.prepareCall(sql);
        } else {
            ps = connection.prepareStatement(sql);
        }

        for (int i = 0; i < args.length; i++) {
            ps.setObject(i + 1, args[i]);
        }
        
        // The following line should be removed:
        // ResultSet rs = ps.executeQuery();
        
        return ps;
        
    } catch (SQLException e) {
        throw new RuntimeException(e);
    }
}

    
    /*
     * Thực hiện câu lệnh SQL thao tác (INSERT, UPDATE, DELETE) hoặc thủ tục lưu thao tác dữ liệu
     *
     */
    public static void update(String sql, Object... args) {
        try {
            ps = XJDBC.getStmt(sql, args);
            try {
                ps.executeUpdate();
            } finally {
                ps.getConnection().close();
            }
        } catch (SQLException e) {
//            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /*
     * Thực hiện câu lệnh SQL truy vấn (SELECT) hoặc thủ tục lưu truy vấn dữ liệu
     */
    public static ResultSet query(String sql, Object... args) {
        try {
            ps = XJDBC.getStmt(sql, args);
            return ps.executeQuery();
        } catch (SQLException e) {
//            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static Object value(String sql, Object... args) {
        try {
            rs = XJDBC.query(sql, args);
            if (rs.next()) {
                return rs.getObject(1); // Sử dụng chỉ số 1 thay vì 0
            }
            rs.getStatement().getConnection().close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            // Đảm bảo đóng tài nguyên ResultSet
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
        return null;
    }

}
