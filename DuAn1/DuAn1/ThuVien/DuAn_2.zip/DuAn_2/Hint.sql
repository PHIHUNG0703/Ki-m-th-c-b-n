
--Số lượng khóa học theo chuyên đề
select top 5 k.MaCD, count(k.MaKH) as "SLKH"
from ChuyenDe c INNER JOIN KhoaHoc k
ON c.MaCD = k.MaCD
group by k.MaCD

--Số lượng khóa học và số lượng học viên theo chuyên đề
select top 5 k.MaCD, t.SLKH, count(h.MaHV) as "SLHV"
from KhoaHoc k
	INNER JOIN HocVien h ON k.MaKH = h.MaKH
	INNER JOIN 
		(select k.MaCD, count(k.MaKH) as "SLKH"
		from ChuyenDe c INNER JOIN KhoaHoc k
		ON c.MaCD = k.MaCD
		group by k.MaCD) t 
			ON k.MaCD = t.MaCD
group by k.MaCD, t.SLKH



